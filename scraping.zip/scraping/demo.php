<?php
// check url :https://davidwalsh.name/php-notifications
include("simple_html_dom.php");
//$html = 'http://www.aora2017.com';
//  $output = file_get_contents($url); 
// echo $output;
 $html = file_get_html('http://www.aora2017.com/');

// Find all images 
foreach($html->find('img') as $element) 
       echo $element->src . '<br>';

// Find all links 
foreach($html->find('a') as $element) 
       echo $element->href . '<br>';
?>
